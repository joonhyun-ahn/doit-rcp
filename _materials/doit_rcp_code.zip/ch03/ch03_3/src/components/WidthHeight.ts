export type WidthHeight = {
  width?: string
  height?: string
}
