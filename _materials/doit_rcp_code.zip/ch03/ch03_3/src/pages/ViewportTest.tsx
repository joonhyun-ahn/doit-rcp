import {Title} from '../components'

export default function ViewportTest() {
  return (
    <section className="w-screen h-screen mt-4 bg-indigo-900">
      <Title className="text-white">ViewportTest</Title>
    </section>
  )
}
