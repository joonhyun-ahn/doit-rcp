export default function CopyMe() {
  return <div>CopyMe</div>
}
